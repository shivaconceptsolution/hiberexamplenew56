package join;

public class Customer {
private int custid;
private String custname;
private int fid;
public int getCustid() {
	return custid;
}
public void setCustid(int custid) {
	this.custid = custid;
}
public String getCustname() {
	return custname;
}
public void setCustname(String custname) {
	this.custname = custname;
}
public int getFid() {
	return fid;
}
public void setFid(int fid) {
	this.fid = fid;
}

}
