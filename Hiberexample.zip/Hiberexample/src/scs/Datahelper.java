package scs;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Datahelper {
	 Configuration cfg; 
	 SessionFactory sf;
	 Session s;
   public void connetion()
   {
	    cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		sf= cfg.buildSessionFactory();
		
		
   }
   public void insertOperation(Object o){
	    s = sf.openSession();
		Transaction tx = s.beginTransaction();
		s.save(o);
		tx.commit();
		
   }
   public void updateOperation(Object o1)
   {
	   s = sf.openSession();
	   Transaction tx = s.beginTransaction();
	  
		s.update(o1);
		tx.commit();
	
   }
   public void deleteOperation(int id,Class c)
   {
	 
	   Transaction tx = s.beginTransaction();
	   Object o = s.get(c,new Integer(id));
		s.delete(o);
		tx.commit();
		
   }
   public Object findOperation(int id, Class c)
   {
	  
	   s = sf.openSession();
	   Object o = s.get(c,new Integer(id));
	   return o;
	   
   }
   public List selectOperation(String query)
   {
	   s = sf.openSession();
	   return s.createQuery(query).list();
   }
   public void closeConnection()
   {
	   s.close();
   }
}
