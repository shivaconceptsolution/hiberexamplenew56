package scs;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentMain {
public static void main(String args[])
{
	Scanner sc = new Scanner(System.in);
	System.out.println("enter rno");
	int x = sc.nextInt();
	System.out.println("enter new name");
	String n = sc.next();
	System.out.println("enter new branch");
	String b = sc.next();
	System.out.println("enter new fee");
	int f = sc.nextInt();
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory sf = cfg.buildSessionFactory();
	Session s = sf.openSession();
	Transaction tx = s.beginTransaction();
	Student stu = new Student();
	stu.setRno(x);
	stu.setSname(n);
	stu.setBranch(b);
	stu.setFees(f);
	s.save(stu);
	tx.commit();
	s.close();
	
}
}
