package scs;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentOp {

	public void insertStudent()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter rno");
		int x = sc.nextInt();
		System.out.println("enter new name");
		String n = sc.next();
		System.out.println("enter new branch");
		String b = sc.next();
		System.out.println("enter new fee");
		int f = sc.nextInt();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		Student stu = new Student();
		stu.setRno(x);
		stu.setSname(n);
		stu.setBranch(b);
		stu.setFees(f);
		s.save(stu);
		tx.commit();
		s.close();
	}
	public void updateStudent()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Which rollno do you want to update?");
		int x = sc.nextInt();
		System.out.println("enter new name");
		String n = sc.next();
		System.out.println("enter new branch");
		String b = sc.next();
		System.out.println("enter new fee");
		int f = sc.nextInt();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		Object o = s.get(Student.class,new Integer(x));
		Student stu =(Student)o;
	    stu.setSname(n);
		stu.setBranch(b);
		stu.setFees(f);
		s.update(stu);
		tx.commit();
		s.close();
	}
	public void deleteStudent()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Which rollno do you want to delete?");
		int x = sc.nextInt();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		Object o = s.get(Student.class,new Integer(x));
		Student stu =(Student)o;
	   
		s.delete(stu);
		tx.commit();
		s.close();
	}
	public void showStudent()
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Query q  = s.createQuery("from Student s");
		List lst = q.list();
		Iterator it = lst.iterator();
		while(it.hasNext())
		{
			Student o =(Student)it.next();
			System.out.println(o.getRno() + " " + o.getSname() + " "+o.getBranch() + " "+o.getFees());
		}
		s.close();
	}
	public static void main(String[] args) {
		StudentOp obj = new StudentOp();
		obj.insertStudent();
		obj.showStudent();

	}

}
