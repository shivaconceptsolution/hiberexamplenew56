package scs;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentOp {
	Datahelper conn;
    StudentOp()
    {
    	conn = new Datahelper();
    	conn.connetion();
    }
	public void insertStudent()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter rno");
		int x = sc.nextInt();
		System.out.println("enter new name");
		String n = sc.next();
		System.out.println("enter new branch");
		String b = sc.next();
		System.out.println("enter new fee");
		int f = sc.nextInt();
		
		Student stu = new Student();
		stu.setRno(x);
		stu.setSname(n);
		stu.setBranch(b);
		stu.setFees(f);
		conn.connetion();
		conn.insertOperation(stu);
		
	}
	public void updateStudent()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Which rollno do you want to update?");
		int x = sc.nextInt();
		System.out.println("enter new name");
		String n = sc.next();
		System.out.println("enter new branch");
		String b = sc.next();
		System.out.println("enter new fee");
		int f = sc.nextInt();
		
		Object o =conn.findOperation(new Integer(x),Student.class);
		conn.closeConnection();
		Student stu =(Student)o;
	    stu.setSname(n);
		stu.setBranch(b);
		stu.setFees(f);
		conn.updateOperation(stu);
	}
	public void deleteStudent()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Which rollno do you want to delete?");
		int x = sc.nextInt();
		
		conn.deleteOperation(x,Student.class);

		
	   
		
	}
	public void showStudent()
	{
		
		List lst = conn.selectOperation("from Student s");
		Iterator it = lst.iterator();
		while(it.hasNext())
		{
			Student o =(Student)it.next();
			System.out.println(o.getRno() + " " + o.getSname() + " "+o.getBranch() + " "+o.getFees());
		}
		
	}
	public void closeConnection()
	{
		conn.closeConnection();
	}
	public static void main(String[] args) {
		StudentOp obj = new StudentOp();
		
		//obj.insertStudent();
		obj.updateStudent();
		//obj.deleteStudent();
		obj.showStudent();
		obj.closeConnection();

	}

}
