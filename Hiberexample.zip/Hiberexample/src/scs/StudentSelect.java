package scs;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.*;
public class StudentSelect {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Criteria q = s.createCriteria(Student.class);
		
		//Criterion ct = Restrictions.eq("branch","cs");
	//	ArrayList arr = new ArrayList();
	//	arr.add("CS");
	//	arr.add("EC");
	//	Criterion ct = Restrictions.in("branch",arr);
	//	Criterion ct = Restrictions.between("fees",5000,20000);
	//	Criterion ct = Restrictions.like("sname","K",MatchMode.START);
		//Criterion ct = Restrictions.like("sname","k%r");
		//Criterion ct = Restrictions.like("sname","k",MatchMode.ANYWHERE);
	//	Criterion ct = Restrictions.gt("fees",50000);
	
		//q.add(ct);
	    //q.setProjection(Projections.property("rno"));
		ProjectionList p1=Projections.projectionList();
		p1.add(Projections.property("rno"));
		p1.add(Projections.property("fees"));
		q.setProjection(p1);
		List lst = q.list();
		Iterator it = lst.iterator();
		while(it.hasNext())
		{
			Object o[] =(Object[])it.next();
			System.out.println(o[0] + " "+o[1]);
		}
		s.close();

	}

}
